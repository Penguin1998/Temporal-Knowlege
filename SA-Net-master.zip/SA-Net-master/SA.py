import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl.function as fn
import math
import numpy as np
import pdb

import torch
from torch import nn
import numpy as np

from preprocess import padding_mask, sequence_mask,del_tensor_0_cloumn

from math import sqrt
import numpy as np
import torch
import torch.nn as nn

class PositionalEncoding(nn.Module):

    def __init__(self, d_model, max_seq_len):
        """初始化。
        Args:
            d_model: 一个标量。模型的维度，论文默认是512
            max_seq_len: 一个标量。文本序列的最大长度
        """
        super(PositionalEncoding, self).__init__()

        # 根据论文给的公式，构造出PE矩阵
        position_encoding = np.array([
            [pos / np.power(10000, 2.0 * (j // 2) / d_model) for j in range(d_model)]
            for pos in range(max_seq_len)])
        # 偶数列使用sin，奇数列使用cos
#         position_encoding[:, 0::2] = np.sin(position_encoding[:, 0::2])
#         position_encoding[:, 1::2] = np.cos(position_encoding[:, 1::2])

        # 在PE矩阵的第一行，加上一行全是0的向量，代表这`PAD`的positional encoding
        # 在word embedding中也经常会加上`UNK`，代表位置单词的word embedding，两者十分类似
        # 那么为什么需要这个额外的PAD的编码呢？很简单，因为文本序列的长度不一，我们需要对齐，
        # 短的序列我们使用0在结尾补全，我们也需要这些补全位置的编码，也就是`PAD`对应的位置编码
        pad_row = torch.zeros([1, d_model])  # [1, max_seq_len]
        position_encoding = torch.cat((pad_row, torch.tensor(position_encoding, dtype=torch.float)), dim=0)

        # 嵌入操作，+1是因为增加了`PAD`这个补全位置的编码，
        # Word embedding中如果词典增加`UNK`，我们也需要+1。看吧，两者十分相似
        self.position_encoding = nn.Embedding(max_seq_len +1, d_model)
        self.position_encoding.weight = nn.Parameter(position_encoding,
                                                     requires_grad=False)

    def forward(self,input_len,max_len):
        """神经网络的前向传播。
        Args:
          input_len: 一个张量，形状为[BATCH_SIZE, 1]。每一个张量的值代表这一批文本序列中对应的长度。
        Returns:
          返回这一批序列的位置编码，进行了对齐。
        """

        # 找出这一批序列的最大长度
        max_len = max_len
        tensor = torch.cuda.LongTensor if input_len.is_cuda else torch.LongTensor
        # 对每一个序列的位置进行对齐，在原序列位置的后面补上0
        # 这里range从1开始也是因为要避开PAD(0)的位置
        input_pos = tensor(
            [list(range(1, len + 1)) + [0] * (max_len - len) for len in input_len])
        return self.position_encoding(input_pos)



class SA(nn.Module):
    def __init__(self, in_feat, out_feat,  bias=True, activation=None,
                 self_loop=True, dropout=0.0):
        super(SA, self).__init__()
        self.q_linear = nn.Linear(in_feat, in_feat, bias=False)
        self.k_linear = nn.Linear(in_feat, in_feat, bias=False)
        self.v_linear = nn.Linear(in_feat, out_feat, bias=False)
        self.mask=True
        self.in_feat = in_feat
        self.out_feat = out_feat
        self.learnable_lambda=True
        self.dim_k = in_feat
        self.dim_v = out_feat
        self.h = 8
        self.d_k = in_feat // self.h
        self.d_v = out_feat // self.h
        self.exponential_decay = nn.Linear(1, 1)
    def forward(self,x):
        all_time_embeds=x[0]
        cur_embeddings=x[1]
        time_decay=x[3]


        if x[2]==None:
            time_decay=x[3].unsqueeze(0)
            if self.learnable_lambda:
                decay_weight =self.exponential_decay(time_decay.unsqueeze(2)).squeeze(2)
            else:
                decay_weight = 0
            self.mask=False
        else:
            if self.learnable_lambda:
                decay_weight =self.exponential_decay(time_decay.unsqueeze(2)).squeeze(2)
            else:
                decay_weight = 0
            local_attn_mask=padding_mask(x[2])
            
            
        bs = all_time_embeds.shape[0]
        q = self.q_linear(cur_embeddings).unsqueeze(1).view(bs, -1, self.h, self.d_k).transpose(1, 2)
        k = self.k_linear(all_time_embeds).view(bs, -1, self.h, self.d_k).transpose(1, 2)
        
        v = self.v_linear(all_time_embeds).view(bs, -1, self.h, self.d_v).transpose(1, 2)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_k)

        if self.mask==False:
#             normalised = F.softmax(scores.squeeze(2)+decay_weight.unsqueeze(1), dim=-1)
            normalised = F.softmax(scores.squeeze(2), dim=-1)

        else:
#             normalised = F.softmax(scores.squeeze(2).masked_fill_(local_attn_mask, -np.inf)+decay_weight.unsqueeze(1), dim=-1)
            normalised = F.softmax(scores.squeeze(2).masked_fill_(local_attn_mask, -np.inf), dim=-1)


        output = torch.matmul(normalised.unsqueeze(2), v).squeeze(2)
        tt=0
        return tt,output.transpose(1, 2).contiguous().view(bs, self.out_feat)


