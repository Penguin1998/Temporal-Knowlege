import re

import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import os

# fname 为 你下载的字体库路径，注意 SourceHanSansSC-Bold.otf 字体的路径
# zhfont1 = matplotlib.font_manager.FontProperties(fname="SourceHanSansSC-Bold.otf")
if __name__ == '__main__':
    # data=list(range(1,41,2))
    data=[]
    with open(os.path.join('', 'att.txt'), 'r') as fr:
        for line in fr.readlines():
            a=re.split('[\t\n]', line.strip())
        for i in a:                             
            if i!='YAGO:':
                data.append(float(i))
    Attn_YAGO=data[:20]
    Attn_WIKI=data[20:40]
    print(Attn_WIKI)

    data2=[]
    with open(os.path.join('', 'renet.txt'), 'r') as fr:
        for line in fr.readlines():
            b=re.split('[\t\n]', line.strip())
        for i in b:
            if i!='YAGO:':
                data2.append(float(i))
    renet_YAGO=data2[:20]
    renet_WIKI=data2[20:40]
    print(renet_WIKI)
    # print(len(renet_WIKI))
    # print(len(renet_YAGO))
    x = np.arange(1, 21)
    y = 2 * x + 5
    plt.title("WIKI", )

    # fontproperties 设置中文显示，fontsize 设置字体大小
    plt.xlabel("epoch", )
    plt.ylabel("mrr", )
    plt.plot( x,Attn_WIKI,label='$Attn-Net$',color="g",linewidth=1.5)
    plt.plot(x, renet_WIKI,label='RE-Net',color="blue",linewidth=1.5)
    plt.legend()
    plt.savefig('WIKI.jpg')
    plt.show()
