
import numpy as np
import os
from collections import defaultdict
import pickle
import dgl
import torch


if __name__ == '__main__':
    with open(os.path.join('', 'train.txt'), 'r') as fr:
        quadrupleList=[]
        for line in fr:
            line_split = line.split()
            head = int(line_split[0])
            tail = int(line_split[2])
            rel = int(line_split[1])
            time = int(line_split[3])
            quadrupleList.append([head, rel, tail, time])
        # print(quadrupleList)
    train=quadrupleList[:94026]
    print(train[-1])
    valid=quadrupleList[94026:133868]
    print(valid[-1])
    test=quadrupleList[133868:151676]
    print(test[-1])

    with open('train2.txt', 'w') as file_object:
        for i in train:
            file_object.write(str(i[0]))
            file_object.write('\t')
            file_object.write(str(i[1]))
            file_object.write('\t')
            file_object.write(str(i[2]))
            file_object.write('\t')
            file_object.write(str(i[3]))
            file_object.write('\n')
    with open('valid2.txt', 'w') as file_object:
        for i in valid:
            file_object.write(str(i[0]))
            file_object.write('\t')
            file_object.write(str(i[1]))
            file_object.write('\t')
            file_object.write(str(i[2]))
            file_object.write('\t')
            file_object.write(str(i[3]))
            file_object.write('\n')
    with open('test2.txt', 'w') as file_object:
        for i in test:
            file_object.write(str(i[0]))
            file_object.write('\t')
            file_object.write(str(i[1]))
            file_object.write('\t')
            file_object.write(str(i[2]))
            file_object.write('\t')
            file_object.write(str(i[3]))
            file_object.write('\n')


# with open('train_graphs.txt', 'wb') as fp:
#     pickle.dump(graph_dict_train, fp)